<?php return array (
  'parameters' => 
  array (
    'database_host' => '127.0.0.1',
    'database_port' => '',
    'database_name' => 'ps1712',
    'database_user' => 'root',
    'database_password' => '',
    'database_prefix' => 'ps_',
    'database_engine' => 'InnoDB',
    'mailer_transport' => 'smtp',
    'mailer_host' => '127.0.0.1',
    'mailer_user' => NULL,
    'mailer_password' => NULL,
    'secret' => 'LYG1UhK1Suyjz7GgjSKDM3cKJBHxMJchUX61nhGfjcodhnYGVkskEWik',
    'ps_caching' => 'CacheMemcache',
    'ps_cache_enable' => false,
    'ps_creation_date' => '2017-06-15',
    'locale' => 'fr-FR',
    'cookie_key' => 'bIZjV6Xvkrx70QBZTCFTwwQTKs8PRwJL7QJPy4vOcwzVAceqxpZz6k0A',
    'cookie_iv' => '4gAxZBgj',
    'new_cookie_key' => 'def0000004b8b09368b8e6f6a3a41593d461003f2eb7598fddc0ddb4bbf821dcdd6b04243b0f4d4d2019542c76795e47abe96134dccdcdfde70d69e244762a73bb809f70',
  ),
);