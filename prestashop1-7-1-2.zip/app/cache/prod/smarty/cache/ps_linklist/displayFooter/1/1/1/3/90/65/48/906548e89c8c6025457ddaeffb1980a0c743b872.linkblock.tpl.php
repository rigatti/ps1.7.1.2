<?php /*%%SmartyHeaderCode:261015942e40656bda7-06613809%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '906548e89c8c6025457ddaeffb1980a0c743b872' => 
    array (
      0 => 'module:ps_linklist/views/templates/hook/linkblock.tpl',
      1 => 1495442840,
      2 => 'module',
    ),
  ),
  'nocache_hash' => '261015942e40656bda7-06613809',
  'variables' => 
  array (
    'linkBlocks' => 0,
    'linkBlock' => 0,
    '_expand_id' => 0,
    'link' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_5942e4066a6d13_81607844',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5942e4066a6d13_81607844')) {function content_5942e4066a6d13_81607844($_smarty_tpl) {?><div class="col-md-4 links">
  <div class="row">
      <div class="col-md-6 wrapper">
      <h3 class="h3 hidden-sm-down">produits</h3>
            <div class="title clearfix hidden-md-up" data-target="#footer_sub_menu_92728" data-toggle="collapse">
        <span class="h3">produits</span>
        <span class="pull-xs-right">
          <span class="navbar-toggler collapse-icons">
            <i class="material-icons add">&#xE313;</i>
            <i class="material-icons remove">&#xE316;</i>
          </span>
        </span>
      </div>
      <ul id="footer_sub_menu_92728" class="collapse">
                  <li>
            <a
                id="link-product-page-prices-drop-1"
                class="cms-page-link"
                href="http://127.0.0.1/fr/promotions"
                title="Produits en promotion">
              Promotions
            </a>
          </li>
                  <li>
            <a
                id="link-product-page-new-products-1"
                class="cms-page-link"
                href="http://127.0.0.1/fr/nouveaux-produits"
                title="Nos nouveaux produits">
              Nouveaux produits
            </a>
          </li>
                  <li>
            <a
                id="link-product-page-best-sales-1"
                class="cms-page-link"
                href="http://127.0.0.1/fr/meilleures-ventes"
                title="Nos meilleures ventes">
              Meilleures ventes
            </a>
          </li>
              </ul>
    </div>
      <div class="col-md-6 wrapper">
      <h3 class="h3 hidden-sm-down">Notre société</h3>
            <div class="title clearfix hidden-md-up" data-target="#footer_sub_menu_25822" data-toggle="collapse">
        <span class="h3">Notre société</span>
        <span class="pull-xs-right">
          <span class="navbar-toggler collapse-icons">
            <i class="material-icons add">&#xE313;</i>
            <i class="material-icons remove">&#xE316;</i>
          </span>
        </span>
      </div>
      <ul id="footer_sub_menu_25822" class="collapse">
                  <li>
            <a
                id="link-cms-page-1-2"
                class="cms-page-link"
                href="http://127.0.0.1/fr/content/1-livraison"
                title="Nos conditions de livraison">
              Livraison
            </a>
          </li>
                  <li>
            <a
                id="link-cms-page-2-2"
                class="cms-page-link"
                href="http://127.0.0.1/fr/content/2-mentions-legales"
                title="Mentions légales">
              Mentions légales
            </a>
          </li>
                  <li>
            <a
                id="link-cms-page-3-2"
                class="cms-page-link"
                href="http://127.0.0.1/fr/content/3-conditions-utilisation"
                title="Nos conditions d&#039;utilisation">
              Conditions d&#039;utilisation
            </a>
          </li>
                  <li>
            <a
                id="link-cms-page-4-2"
                class="cms-page-link"
                href="http://127.0.0.1/fr/content/4-a-propos"
                title="En savoir plus sur notre entreprise">
              A propos
            </a>
          </li>
                  <li>
            <a
                id="link-cms-page-5-2"
                class="cms-page-link"
                href="http://127.0.0.1/fr/content/5-paiement-securise"
                title="Notre méthode de paiement sécurisé">
              Paiement sécurisé
            </a>
          </li>
                  <li>
            <a
                id="link-static-page-contact-2"
                class="cms-page-link"
                href="http://127.0.0.1/fr/nous-contacter"
                title="Utiliser le formulaire pour nous contacter">
              Nous contacter
            </a>
          </li>
                  <li>
            <a
                id="link-static-page-sitemap-2"
                class="cms-page-link"
                href="http://127.0.0.1/fr/plan-site"
                title="Vous êtes perdu ? Trouvez ce que vous cherchez">
              Plan du site
            </a>
          </li>
                  <li>
            <a
                id="link-static-page-stores-2"
                class="cms-page-link"
                href="http://127.0.0.1/fr/magasins"
                title="">
              Magasins
            </a>
          </li>
              </ul>
    </div>
    </div>
</div>
<?php }} ?>
