<?php /*%%SmartyHeaderCode:200985942e404cd0877-84571366%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '64034093fbda864710a2c0f526b37f921e53ee39' => 
    array (
      0 => 'module:ps_banner/ps_banner.tpl',
      1 => 1495442840,
      2 => 'module',
    ),
  ),
  'nocache_hash' => '200985942e404cd0877-84571366',
  'variables' => 
  array (
    'banner_link' => 0,
    'banner_desc' => 0,
    'banner_img' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_5942e404d8c321_59874567',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5942e404d8c321_59874567')) {function content_5942e404d8c321_59874567($_smarty_tpl) {?><a class="banner hidden-sm-down" href="http://127.0.0.1/fr/" title="">
      <img src="http://127.0.0.1/modules/ps_banner/img/sale70.png" alt="" title="" class="img-fluid">
  </a>
<?php }} ?>
