<?php /* Smarty version Smarty-3.1.19, created on 2017-06-15 21:52:30
         compiled from "C:\wamp\www\prestashop1-7-1-2\modules\welcome\views\templates\tooltip.tpl" */ ?>
<?php /*%%SmartyHeaderCode:185765942e57e857b82-38458865%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd86f957c2b3d7069bd5b9c03c8330faef47abea1' => 
    array (
      0 => 'C:\\wamp\\www\\prestashop1-7-1-2\\modules\\welcome\\views\\templates\\tooltip.tpl',
      1 => 1495442970,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '185765942e57e857b82-38458865',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_5942e57e86afb9_06437634',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5942e57e86afb9_06437634')) {function content_5942e57e86afb9_06437634($_smarty_tpl) {?>

<div class="onboarding-tooltip">
  <div class="content"></div>
  <div class="onboarding-tooltipsteps">
    <div class="total"><?php echo smartyTranslate(array('s'=>'Step','d'=>'Modules.Welcome.Admin'),$_smarty_tpl);?>
 <span class="count">1/5</span></div>
    <div class="bulls">
    </div>
  </div>
  <button class="btn btn-primary btn-xs onboarding-button-next"><?php echo smartyTranslate(array('s'=>'Next','d'=>'Modules.Welcome.Admin'),$_smarty_tpl);?>
</button>
</div>
<?php }} ?>
