<?php /* Smarty version Smarty-3.1.19, created on 2017-06-15 21:52:08
         compiled from "C:\wamp\www\prestashop1-7-1-2\admin1712\themes\default\template\controllers\login\layout.tpl" */ ?>
<?php /*%%SmartyHeaderCode:135735942e5689d01f9-04418154%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '750d2c35d38aea88e74d439034559d11adb53749' => 
    array (
      0 => 'C:\\wamp\\www\\prestashop1-7-1-2\\admin1712\\themes\\default\\template\\controllers\\login\\layout.tpl',
      1 => 1495442840,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '135735942e5689d01f9-04418154',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'header' => 0,
    'page' => 0,
    'footer' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_5942e5689e76a8_55158881',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5942e5689e76a8_55158881')) {function content_5942e5689e76a8_55158881($_smarty_tpl) {?>

<?php echo $_smarty_tpl->tpl_vars['header']->value;?>

<?php echo $_smarty_tpl->tpl_vars['page']->value;?>

<?php echo $_smarty_tpl->tpl_vars['footer']->value;?>

<?php }} ?>
