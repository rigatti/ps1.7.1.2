<?php /* Smarty version Smarty-3.1.19, created on 2017-06-15 21:52:30
         compiled from "C:\wamp\www\prestashop1-7-1-2\modules\welcome\views\templates\lost.tpl" */ ?>
<?php /*%%SmartyHeaderCode:274585942e57e7729f9-76738605%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1f30c8d3aba2d655a278c6109e07515b9cae425c' => 
    array (
      0 => 'C:\\wamp\\www\\prestashop1-7-1-2\\modules\\welcome\\views\\templates\\lost.tpl',
      1 => 1495442970,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '274585942e57e7729f9-76738605',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_5942e57e7a4eb8_92791755',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5942e57e7a4eb8_92791755')) {function content_5942e57e7a4eb8_92791755($_smarty_tpl) {?>

<div class="onboarding onboarding-popup bootstrap">
  <div class="content">
    <p><?php echo smartyTranslate(array('s'=>'Hey! Are you lost?','d'=>'Modules.Welcome.Admin'),$_smarty_tpl);?>
</p>
    <p><?php echo smartyTranslate(array('s'=>'To continue, click here:','d'=>'Modules.Welcome.Admin'),$_smarty_tpl);?>
</p>
    <div class="text-center">
      <button class="btn btn-primary onboarding-button-goto-current"><?php echo smartyTranslate(array('s'=>'Continue','d'=>'Modules.Welcome.Admin'),$_smarty_tpl);?>
</button>
    </div>
    <p><?php echo smartyTranslate(array('s'=>'If you want to stop the tutorial for good, click here:','d'=>'Modules.Welcome.Admin'),$_smarty_tpl);?>
</p>
    <div class="text-center">
      <button class="btn btn-alert onboarding-button-stop"><?php echo smartyTranslate(array('s'=>'Quit the Welcome tutorial','d'=>'Modules.Welcome.Admin'),$_smarty_tpl);?>
</button>
    </div>
  </div>
</div>
<?php }} ?>
