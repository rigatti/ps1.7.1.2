<?php /* Smarty version Smarty-3.1.19, created on 2017-06-15 21:52:30
         compiled from "C:\wamp\www\prestashop1-7-1-2\modules\welcome\views\templates\popup.tpl" */ ?>
<?php /*%%SmartyHeaderCode:305475942e57e8148d9-54567513%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '99146b9c929659e4fe3d96939c5b8bf16527164e' => 
    array (
      0 => 'C:\\wamp\\www\\prestashop1-7-1-2\\modules\\welcome\\views\\templates\\popup.tpl',
      1 => 1495442970,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '305475942e57e8148d9-54567513',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_5942e57e8189c3_53740613',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5942e57e8189c3_53740613')) {function content_5942e57e8189c3_53740613($_smarty_tpl) {?>

<div class="onboarding-popup bootstrap">
  <div class="content"></div>
</div>
<?php }} ?>
